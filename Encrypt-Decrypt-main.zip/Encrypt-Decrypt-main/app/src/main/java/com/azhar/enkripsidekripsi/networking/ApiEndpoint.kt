package com.azhar.enkripsidekripsi.networking

/**
 * Created by Azhar Rivaldi on 01-05-2021
 * Youtube Channel : https://bit.ly/2PJMowZ
 * Github : https://github.com/AzharRivaldi
 * Twitter : https://twitter.com/azharrvldi_
 * Instagram : https://www.instagram.com/azhardvls_
 * Linkedin : https://www.linkedin.com/in/azhar-rivaldi
 */

object ApiEndpoint {
    val BASEURL_ENCRYPT = "https://hadi-api.herokuapp.com/api/base64?teks={encrypt}&method=encrypt"
    val BASEURL_DECRYPT = "https://hadi-api.herokuapp.com/api/base64?teks={decrypt}&method=decrypt"
}
